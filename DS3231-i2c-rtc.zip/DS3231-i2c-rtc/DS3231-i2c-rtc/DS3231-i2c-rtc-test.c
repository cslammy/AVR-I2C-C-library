/*
 * DS3231-i2c-rtc.c
*reads values from inexpensive I2C RTC IC
* BoB based on Maxim DS3231
datasheet: https://datasheets.maximintegrated.com/en/ds/DS3231.pdf
* you can set time but only using binary (sorry)
* alarms dates etc. not supported 
* Why? Eat less dried fruit!!
 */ 
//
//
//
/* what is BCD?  
Old school way to express numbers
for thing like time displays, calculators
and printers.

LSB and MSB are both expressed
as nibbles. so you'll need to multiply LSB by something (10?) and
then add it to LSB.
*/

#define F_CPU 16000000UL
#define BAUD 9600
#define BAUD_TOL 2

#include <avr/io.h>
#include "I2C.h"
#include <stdio.h>
#include "stdio_setup.h" // printf dukey
#include <util/delay.h>


//read variables      
char sec = 0;
char min = 0;
char hours=0;


void read_IC(void);

void settime(char sethrs, char setminutes, char setseconds);

char address = 0xD0; // address of RTC
char readaddress = 0xD1; // address of RTC for read

int main(void)
{ 
    
     		
	UartInit(); // initialize stdio_setup-the printf serial puker
    I2C_Init();
	

	//set time here.  
	/* set hour is tricky on DipS**t3231:
	
	bit 7 always 0
	bit 6  1 is 12 hrs 0 is 24 hr time 
	bit 5  1 is AM in 12 hr mode 0 is PM
	bit 5  20 hour in 24 hr mode
	bit 4  10 hr
	bit 3-2-1 BCD of hr
	happy coding ya old fart
	*/
	
	//uncomment to set time on RTC IC
	/*
    char sethrs = 0;
    char setminutes = 0;
    char setseconds = 0;
	sethrs = 0b01001000; // 8AM 12 hr
	setminutes = 0b00100001; // minutes in BCD 
	setseconds = 0b00000000; // secs in BCD
	settime(sethrs, setminutes, setseconds);
	*/
	
    while (1) 
    {
        read_IC();  		
		_delay_ms(100);  
    }
}



void read_IC(void)
{
	char hourslsb = 0;
	char hoursmsb = 0;
	char hoursfinal = 0;
	char secmsb = 0;
	char seclsb = 0;
	char secfinal = 0;
	char minmsb = 0;
	char minlsb = 0;
	char minfinal = 0;

	
    
    I2C_Start();

    I2C_Write(address); // send  addr. to chip
    // get data from RTC /
    I2C_Write(0x00); // send  register to chip
    I2C_Start();
	I2C_Write(readaddress);
    sec = I2C_ReadACK();
    secmsb = sec & 0b01110000;
	seclsb = sec & 0b00001111;
	secfinal = ((secmsb >> 4)*10) + (seclsb);
	//printf("sec value is: %d\n\r",secfinal);
	min = I2C_ReadACK();
    
    minmsb = min & 0b01110000;
    minlsb = min & 0b00001111;
    minfinal = ((minmsb >> 4)*10) + (minlsb);
    //printf("min sec  value is: %d:%d\n\r",minfinal,secfinal);
    hours = I2C_ReadNACK();
	hourslsb = hours & 0b00001111;
	hoursmsb = hours & 0b11110000;
	
	if (hoursmsb & 0b01000000)
	{
		
		unsigned int hours12 = 0;
		hours12 = hours & 00010000;
		hoursfinal = (hours12 * 10) + hourslsb; 
		
		printf("  12 hours minutes secs value is: %d:%d:%02d\n\r",hoursfinal,minfinal,secfinal);
		
		
	}
	else
	{
		
		hoursmsb = hours & 00110000;
		hoursfinal = ((hoursmsb & 00100000) * 20) + ((hoursmsb & 00010000) * 10) + hourslsb;
		
		printf("  24 hours minutes secs value is: %d:%d:%02d\n\r",hoursfinal,minfinal,secfinal);
	}
	

	
	
	


    I2C_Stop();
}


void settime(char sethours, char setmin, char setsec)
{
    I2C_Start();

    I2C_Write(address); // send  addr. to chip	
	I2C_Write(0x00); // send  reg. to chip
    I2C_Write(setsec);
	I2C_Stop();
	
	
	I2C_Start();
	I2C_Write(address);
	I2C_Write(0x01);
    I2C_Write(setmin);
    I2C_Stop();
	
	
	I2C_Start();
	I2C_Write(address);
	I2C_Write(0x02);
    I2C_Write(sethours);		
	I2C_Stop();
}
 
 /*
   
	 Dukey for more programming fun (not now--probably not ever....)       

	day = I2C_ReadACK();



  
    month = I2C_ReadACK();
     
 
	 

    year = I2C_ReadACK();
    

	
	

	alsec1 = I2C_ReadACK();
    

	

	almin1 = I2C_ReadACK();
	

	alhour1 = I2C_ReadACK();
	

    alday1 = I2C_ReadACK();

    aldate1 = I2C_ReadACK();

    almin2 = I2C_ReadACK();

    alhour2 = I2C_ReadACK();

    alday2 = I2C_ReadACK();

    aldaydate2 = I2C_ReadACK();

	
    contrl = I2C_ReadACK();

	stat = I2C_ReadACK();
  
    age = I2C_ReadACK();

	tempmsb = I2C_ReadACK();

    templsb =  I2C_ReadNACK();

    */
 
 /*
       char day;
       char date;
       
       char month;
       char year;
       char alsec1;
       char almin1;
       char alhour1;
       char alday1;
       char aldate1;

       char almin2;
       char alhour2;
       char alday2;
       char aldaydate2;
       char contrl;
       char stat;
       char age;
       char tempmsb;
       char templsb;
	   */
	
	
	
	
	

