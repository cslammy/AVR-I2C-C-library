#include <stdio.h>
#include "stdio_setup.h"
#include <avr/io.h>
#include "i2cmaster.h"
#include "mcp4725write_test.c"

#define PCF8563W  0xA2      // write address for PCF8563 RTC
#define PCF8563R  0xA3 
void readclk (void);

//testing twimaster.c library for writing data to MCP4725, a 12 bit DAC.


uint8_t addressw =  PCF8563W;

// One time write for setup.


i2c_start_wait(addressw);       // set device address and write mode
i2c_write(0x02);  //set up RTC
i2c_stop();  



void readclk (void)
{
    uint8_t addressr =  PCF8563R;
	UartInit();  // allows printf to COM port (like an arduino)
 
	

	i2c_init();                                // initiate I2C interface
	ret2 = i2c_start(addressr);       // set device address and write mode
	if ( ret2 ) {
		/* failed to issue start condition, possibly no device found */
		printf("Cannot find I2C slave device \r\n");
		i2c_stop();
	}
	else {
		
		while(1)
		{
	        uint8_t secs;
			uint8_t mins;
			uint8_t hours;
			uint8_t days;
			uint8_t month;
			uint8_t year;		
			
			secs = i2c_readNak(0x02);
			mins = i2c_readNak(0x03);
			hours = i2c_readNak(0x04);
			days = i2c_readNak(0x05);
			month = i2c_readNak(0x07);
			year = i2c_readAck(0x08);
			

		    printf("date is: %x-%x-%x-%x-%x-%x\r\n",days,month,year,hours,mins,secs);
		}
	}
	i2c_stop();
}



