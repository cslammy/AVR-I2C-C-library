#include <stdio.h>
#include "stdio_setup.h"
#include <avr/io.h>
#include "i2cmaster.h"

#define DAC4725ADDR  0x60      // device address of 4725 12 bit DAC 

void Delay(void);
void readclk (void);

//testing twimaster.c library for writing data to MCP4725, a 12 bit DAC.


uint8_t address =  (DAC4725ADDR << 1);

 // write address for 4725. For I2C write, bit shift left IC's I2C address.
//address = (DAC47625 << 1) + 1));  //read address. For I2C write, bit shift left and add one.


int main(void)
{
	UartInit();  // allows printf to COM port (like an arduino)

		
		unsigned char ret;
	    i2c_init();                                // initiate I2C interface
	    ret = i2c_start(address);       // set device address and write mode
		  if ( ret ) {
			           /* failed to issue start condition, possibly no device found */
		              printf("Cannot find I2C slave device \r\n");
		             i2c_stop();
		             }
	else {
   
			while(1)
			{
			
			i2c_write(0x04);			
			i2c_write(0xFF);	
		//	printf("DEBUG I2C data written \r\n");   
            i2c_write(0x00);
            i2c_write(0xF0);
        //    printf("DEBUG I2C data written \r\n");            			
			} 
          }
i2c_stop();     	
}


void Delay(void)
{
	volatile unsigned long count = 15000;

	while (count--);
}