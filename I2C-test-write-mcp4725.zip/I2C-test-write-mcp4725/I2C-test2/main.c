/*
 * I2C-test2.c
 *
 * Created: 2/12/2021 7:45:16 AM
 * Author : clamm
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

